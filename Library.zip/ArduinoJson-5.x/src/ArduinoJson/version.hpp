// ArduinoJson - arduinojson.org
// Copyright Benoit Blanchon 2014-2019
// MIT License

#pragma once

#define ARDUINOJSON_VERSION "5.13.5"
#define ARDUINOJSON_VERSION_MAJOR 5
#define ARDUINOJSON_VERSION_MINOR 13
#define ARDUINOJSON_VERSION_REVISION 5
